This is an example for custom modules to be used in terraform
